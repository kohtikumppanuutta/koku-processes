var $jq = jQuery.noConflict();
