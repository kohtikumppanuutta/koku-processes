Place your Mapping Rule documents in this folder.
